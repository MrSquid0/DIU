# DIU - Practica 4, entregables


* Users 

Elección y características

* A/B Testing. 
* Tareas realizadas 
* Usability Report de Caso B
* Template de usability.gob
* Conclusiones

Todas las tareas de esta práctica (conclusiones incluidas) están reflejadas en el 
[Informe de usabilidad](https://github.com/MrSquid0/DIU/blob/master/P4/Informe%20de%20usabilidad.pdf).
